class Position:
	def __init__(self, row, column):
		self.row = row
		self.column = column
